<?php
	ini_set('display_errors','on');
	error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
	include_once("../db/01_conn.php");
	
	$mg = '';
	
	$myid = $_POST['myid'];
	if(strlen($myid) != 10)
		$mg = $mg . '身份證字號錯誤';
	$dept = $_POST['dept'];
	$arri = $_POST['arri'];
	$tNo = $_POST['tNo'];
	
	$way12 = $_POST['way12'];
	if($way12 == '1'){
		$trainNo = $_POST['trainNo'];
		$mydate = $_POST['mydate'];
	}
	else{
		$trainNo1 = $_POST['trainNo1'];
		$mydate1 = $_POST['mydate1'];
		$trainNo2 = $_POST['trainNo2'];
		$mydate2 = $_POST['mydate2'];
	}
	
	if($way12 == '1'){
		$oCode = mt_rand(100000, 999999);
		$sql = "INSERT INTO train(tid, myid, dept, arri, way12, mydate, trainNo, tNo, oCode) 
							VALUES(NULL,'$myid','$dept','$arri',$way12,'$mydate','$trainNo',$tNo,'$oCode')";
		try{
			$msg='';
			$result =$connect->exec($sql);
			if($result === false){
				$msg="fail <br>\n";
			} 
			else{
				$msg = "OK <br>\n";
			}
			if($msg != '') echo $msg;
		}catch(PDOException $e){
			echo $e->getMessage() . "<br>\n";
		}
	}
	else{
		$oCode = mt_rand(100000, 999999);
		$sql1 = "INSERT INTO train(tid, myid, dept, arri, way12, mydate, trainNo, tNo, oCode) 
							VALUES(NULL,'$myid','$dept','$arri',$way12,'$mydate1','$trainNo1',$tNo,'$oCode')";
		try{
			$msg='';
			$result =$connect->exec($sql1);
			if($result === false){
				$msg="fail <br>\n";
			} 
			else{
				$msg = "OK <br>\n";
			}
			if($msg != '') echo $msg;
		}catch(PDOException $e){
			echo $e->getMessage() . "<br>\n";
		}
		
		$oCode = mt_rand(100000, 999999);
		$sql2 = "INSERT INTO train(tid, myid, dept, arri, way12, mydate, trainNo, tNo, oCode) 
							VALUES(NULL,'$myid','$arri','$dept',$way12,'$mydate2','$trainNo2',$tNo,'$oCode')";
		try{
			$msg='';
			$result =$connect->exec($sql2);
			if($result === false){
				$msg="fail <br>\n";
			} 
			else{
				$msg = "OK <br>\n";
			}
			if($msg != '') echo $msg;
		}catch(PDOException $e){
			echo $e->getMessage() . "<br>\n";
		}
	}
	
?>