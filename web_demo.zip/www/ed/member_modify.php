<html>
	<head>
		<meta charset="utf-8">
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
		<title>修改會員資料</title>
	</head>
	<body>
		<?php
			session_start();
			if(empty($_SESSION['UID'])) header("refresh:1;url=formLogin.htm");
			
			ini_set('display_errors','on');
			error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
			include_once("../db/01_conn.php");
			
			if(empty($_GET['mid']))
				$sql2="select * from member where uid='". $_SESSION["UID"] . "'";
			else
				$sql2="select * from member where mid='". $_GET['mid'] . "'";
			
			$connect->setAttribute(PDO::ATTR_CASE, PDO::CASE_NATURAL);
			$rs2=$connect->query($sql2);
			$rs2->setFetchMode(PDO::FETCH_BOTH);
			$row2=$rs2->fetch();
		?>
		<div style="padding:5% 15%">
			<form method="post" action="member_modify2.php">
				<input type="hidden" name="mid" value="<?php echo $row2["mid"] ?>">
				<div class="mb-3">
					<label for="exampleInputEmail1" class="form-label">帳號</label>
					<input type="text" name="uid" class="form-control" aria-describedby="emailHelp" value="<?php echo $row2["uid"] ?>">
				</div>
				<div class="mb-3">
					<label for="exampleInputEmail1" class="form-label">密碼</label>
					<input type="text" name="passwd" class="form-control" aria-describedby="emailHelp" value="<?php echo $row2["passwd"] ?>">
				</div>
				<div class="mb-3">
					<label for="exampleInputEmail1" class="form-label">姓名</label>
					<input type="text" name="name2" class="form-control" aria-describedby="emailHelp" value="<?php echo $row2["name"] ?>">
				</div>
				<div class="mb-3">
					<label for="exampleInputEmail1" class="form-label">生日</label>
					<input type="date" name="birthday" class="form-control" aria-describedby="emailHelp" value="<?php echo $row2["birthday"] ?>">
				</div>
				<div class="mb-3">
					<label for="exampleInputEmail1" class="form-label">手機號碼</label>
					<input type="text" name="mobile" class="form-control" aria-describedby="emailHelp" value="<?php echo $row2["mobile"] ?>">
				</div>
				<button type="submit" class="btn btn-primary">修改</button>
			</form>
		</div>
	</body>
</html>