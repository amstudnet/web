<?php
echo "帳號：" . $_POST["myid"] . "<br>";
echo "密碼：" . $_POST["mypw"] . "<br>";
echo "性別：" . $_POST["genderMale"] . $_POST["genderFemale"] . $_POST["genderG"];
?>