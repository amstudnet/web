<?php
ini_set('display_errors','on');
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
include_once("./db/01_conn.php");

$uid = $_POST['uid'];
$passwd = $_POST['password'];
$name = $_POST['name'];
$ID = $_POST['ID'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$position = $_POST['position'];

try{
	$sql = "INSERT INTO peopleData(did, uid, passwd, name, ID, email, phone, position) 
			VALUES (NULL, '$uid', '$passwd', '$name', '$ID', '$email', '$phone', $position)";
	//echo $sql."<br>\n";
	$msg='';

	$result =$connect->exec($sql);
	if($result === false){
		$msg="fail insert. <br>\n";
	} 
	if($msg != '') echo $msg;
	else{
		echo "註冊成功";
		header("refresh:1;url=Login.php");
	}
}catch(PDOException $e){
    echo $e->getMessage() . "<br>\n";
}
?>