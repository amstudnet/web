<?php
	echo date("Y-m-d H:i:s") . "<br>";
	echo t2test(date("N")) . "<br>";
	$nowTime = mktime(date("H"), date("i"), date("s"), date("m"), date("d"), date("Y"));
	echo "nowTime = $nowTime <br>";
	$washEndTime = $nowTime + (32*60);
	echo "washEndTime = " . date("Y-m-d H:i:s", $washEndTime) . "<br>";

	function t2test($tt){
		switch($tt){
			case '1':
				return "週一";
			case '2':
				return "週二";
			case '3':
				return "週三";
			case '4':
				return "週四";
			case '5':
				return "週五";
			case '6':
				return "週六";
			case '7':
				return "週日";
		}
	}
	echo '<select>';
	$days = 28;
	echo '<option selected>選擇日期</option>';
	for($i=0; $i<=$days; $i++){
		echo '<option value="1">', date('Y-m-d', strtotime(sprintf("+%d day",$i))), '</option>';
	}
	echo '</select>';
?>
