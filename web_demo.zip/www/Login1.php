<?php
session_start();
ini_set('display_errors','on');
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
include_once("./db/01_conn.php");

if(!empty($_POST['uid'])) $uid = $_POST['uid'];
if(!empty($_POST['password'])) $passwd = $_POST['password'];

$sql = "SELECT count(*) as CNT FROM peopleData WHERE uid='$uid' and passwd='$passwd'";
$connect->setAttribute(PDO::ATTR_CASE, PDO::CASE_NATURAL);
$rs=$connect->query($sql);
$rs->setFetchMode(PDO::FETCH_BOTH);
$row=$rs->fetch();

if($row["CNT"] == 1){
	if((!empty($_SESSION['check_word'])) && (!empty($_POST['checkword']))){  //判斷此兩個變數是否為空
		if($_SESSION['check_word'] != $_POST['checkword']){
			echo '<div class="text-center" style="padding:200px 15% 10px 15%">
					<p style="font: 50pt 標楷體;">驗證碼輸入錯誤</p>
				</div>';
			header("refresh:1;url=Login.php");
		}
		else{
			$_SESSION['check_word'] = ''; //比對正確後，清空將check_word值
			$sql2 = "SELECT * FROM peopleData WHERE uid='$uid' and passwd='$passwd'";
			$connect->setAttribute(PDO::ATTR_CASE, PDO::CASE_NATURAL);
			$rs2=$connect->query($sql2);
			$rs2->setFetchMode(PDO::FETCH_BOTH);
			$row2=$rs2->fetch();
			$_SESSION['position'] = $row2['position'];
			$_SESSION['did'] = $row2['did'];
			echo '<div class="text-center" style="padding:200px 15% 10px 15%">
					<p style="font: 50pt 標楷體;">登入成功</p>
				</div>';
			header("refresh:1;url=Login.php");
		}
	}	
}
else{
	echo '<div class="text-center" style="padding:200px 15% 10px 15%">
			<p style="font: 50pt 標楷體;">帳號或密碼錯誤</p>
		</div>';
	header("refresh:1;url=Login.php");
}
?>