<?php
	$city = $_POST["city"];
	echo "你的居住地是：" . t2city($city);
	echo "<br>性別：" . t2gender($_POST["gender"]);
	
	function t2city($city){
		switch($city){
			case "1":
				$cityname = "台東";
				break;
			case "2":
				$cityname = "高雄";
				break;
			case "3":
				$cityname = "屏東";
				break;
			case "4":
				$cityname = "台南";
				break;
			default:
				$cityname = "未選擇";
		}
		return $cityname;
	}
	
	function t2gender($gender){
		switch($gender){
			case "0":
				$gendername = "女";
				break;
			case "1":
				$gendername = "男";
				break;
		}
		return $gendername;
	}
?>