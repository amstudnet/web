<?php
ini_set('display_errors','on');
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
include_once("../db/01_conn.php");

$uid = $_POST['uid'];
$passwd = $_POST['password'];
$myname = $_POST['myname'];
$birthday = $_POST['birthday'];
$mobile = $_POST['mobile'];
try{
    
	$sql = "INSERT INTO member(mid, uid, passwd, name, birthday, mobile) 
			VALUES (NULL, '$uid', '$passwd', '$myname', STR_TO_DATE('$birthday', '%Y-%m-%d'), '$mobile')";
	//echo $sql."<br>\n";
	$msg='';

	$result =$connect->exec($sql);
	if($result === false){
		$msg="fail insert. <br>\n";
	} 
	if($msg != '') echo $msg;
}catch(PDOException $e){
    echo $e->getMessage() . "<br>\n";
}
?>