<?php
	session_start();
	if(empty($_SESSION['UID'])){
		echo "未經登入";
		header("refresh:1;url=formLogin.htm");
	}
	else{
		echo $_SESSION['UID'];
		//unset($_SESSION['UID']);
	}
	echo "<a href='member_modify.php'>修改會員資料</a>";
?>