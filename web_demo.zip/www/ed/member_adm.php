<html>
	<head>
		<meta charset="utf-8">
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
		<title>修改會員資料</title>
	</head>
	<body>
		<?php
			session_start();
			if(empty($_SESSION['UID'])) header("refresh:1;url=formLogin.htm");
			
			ini_set('display_errors','on');
			error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
			include_once("../db/01_conn.php");

			$sql2="select * from member";
			$connect->setAttribute(PDO::ATTR_CASE, PDO::CASE_NATURAL);
			$rs2=$connect->query($sql2);
			$rs2->setFetchMode(PDO::FETCH_BOTH);
			echo "<table border='1' width='75%'>";
			echo "<th>序號</th>";
			echo "<th>修改</th>";
			echo "<th>刪除</th>";
			echo "<th>帳號</th>";
			$i = 1;
			while($row2=$rs2->fetch()){
				echo "<tr>";
				echo "<td>$i";
				echo "<td><a href='member_modify.php?mid=" . $row2['mid'] . "'>修改</a>";
				echo "<td><a href='member_del.php?mid=" . $row2['mid'] . "'>刪除</a>";
				echo "<td>" . $row2['uid'];
				$i++;
			}
			echo "</table>";
			echo "新增會員";
		?>
	</body>
</html>