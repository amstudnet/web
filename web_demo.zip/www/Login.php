<html>
	<head>
		<meta charset="utf-8">
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
		<script>
			function refresh_code(){ 
				document.getElementById("imgcode").src="./capt/captcha.php"; 
			}
		</script>		
		<title>出包網</title>
		<style>
			a.focus {
				padding-top: 20px;
				color: #000000;
				text-decoration:none;
				font: 15pt 標楷體;
			}
			
			a.focus:hover{ color: #F28500; }
			
			#case > div > a:hover{ 
				color: #000000;
			}
			
		</style>
	</head>
	<body>
		<div style="padding:30px 15% 5px 15%; background-color:#00C0FF">
			<div class="row">
				<div class="col col-12 col-sm-12 col-md-9 col-lg-6 col-xl-3 text-center">
					<img src="img/Mlogo.jpg" class="img-fluid" style="max-width:100%; height:auto;">
				</div>
				<div class="col col-xs-3 col-sm-3 col-md-6 col-lg-2 col-xl-2 text-center">
					<a href="caseList.php" class="focus">案件查詢</a>
				</div>
				<div class="col col-xs-2 col-sm-2 col-md-6 col-lg-1 col-xl-2 text-center">
					<a href="peopleList.php" class="focus">人才查詢</a>
				</div>
				<div class="col col-xs-2 col-sm-2 col-md-6 col-lg-1 col-xl-2 text-center">
					<a href="" class="focus">發案</a>
				</div>
				<div class="col col-xs-2 col-sm-2 col-md-6 col-lg-1 col-xl-2 text-center">
					<a href="personal.php" class="focus">個人頁面</a>
				</div>
				<div class="col col-xs-3 col-sm-3 col-md-6 col-lg-1 col-xl-1 text-center">
					<?php
						if(!isset($_SESSION)){ session_start(); } //檢查SESSION是否啟動
						if(empty($_SESSION['position']))
							echo '<a href="Login.php" class="focus">登入</a>';
						else
							echo '<a href="Logout.php" class="focus">登出</a>';
					?>
				</div>
			</div>
		</div>
		<div style="padding:5% 15%">
			<form method="post" action="Login1.php">
				<div class="mb-3">
					<label for="exampleInputEmail1" class="form-label">帳號</label>
					<input type="text" name="uid" class="form-control" aria-describedby="emailHelp">
				</div>
				<div class="mb-3">
					<label for="exampleInputPassword1" class="form-label">密碼</label>
					<input type="password" name="password" class="form-control">
				</div>
				<p>請輸入下圖字樣：</p><p><img id="imgcode" src="./capt/captcha.php" onclick="refresh_code()" /><br />
				   點擊圖片可以更換驗證碼
				</p>
				<div class="mb-3">
					<input type="text" name="checkword" size="10" maxlength="10" class="form-control">
				</div>
				<button type="submit" class="btn btn-primary">登入</button>
			</form>
			<a href="register.htm">
				<button class="btn btn-primary">註冊</button>
			</a>
		</div>
	</body>
</html>