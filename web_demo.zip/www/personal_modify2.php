<html>
	<head>
		<meta charset="utf-8">
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
		<title>出包網</title>
		<style>
			a.focus {
				padding-top: 20px;
				color: #000000;
				text-decoration:none;
				font: 15pt 標楷體;
			}
			
			a.focus:hover{ color: #F28500; }
			
			#case > div > a:hover{ 
				color: #000000;
			}
		</style>
	</head>
	<body>
		<?php
			session_start();
			
			ini_set('display_errors','on');
			error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
			include_once("./db/01_conn.php");
			
			$did = S_POST['did'];
			$uid = $_POST['uid'];
			$passwd = $_POST['passwd'];
			$name = $_POST['name'];
			$ID = $_POST['ID'];
			$email = $_POST['email'];
			$phone = $_POST['phone'];
			$introdction = $_POST['introdction'];
			try{
				$sql = "update peopleData SET uid='$uid',passwd='$passwd',name='$name',
						ID='$ID',email='$email',phone='$phone',introdction='$introdction' 
						where did='$did'";
				//echo $sql."<br>\n";
				$msg='';

				$result =$connect->exec($sql);
				if($result === false){
					$msg="fail update. <br>\n";
				} 
				if($msg != '') echo $msg;
				else{
					echo '<div class="text-center" style="padding:200px 15% 10px 15%">
							<p style="font: 50pt 標楷體;">修改成功</p>
						</div>';
					header("refresh:1;url=personal.php");
				}
			}catch(PDOException $e){
				echo $e->getMessage() . "<br>\n";
			}
		?>
	</body>
</html>