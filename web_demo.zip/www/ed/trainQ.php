<?php
session_start();
ini_set('display_errors','on');
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
include_once("../db/01_conn.php");

if(!empty($_POST['oCode'])) $oCode = $_POST['oCode'];
if(!empty($_POST['myid'])) $myid = $_POST['myid'];

echo $_SESSION['check_word'];
if((!empty($_SESSION['check_word'])) && (!empty($_POST['checkword']))){  //判斷此兩個變數是否為空
    if($_SESSION['check_word'] != $_POST['checkword']){
        echo '驗證碼輸入錯誤';
		header("refresh:5;url=trainQ.htm");
		die();
	}
	else{
		$_SESSION['check_word'] = ''; //比對正確後，清空將check_word值
    }
}

$sql = "SELECT count(*) as CNT FROM train WHERE oCode='$oCode' and myid='$myid'";
$connect->setAttribute(PDO::ATTR_CASE, PDO::CASE_NATURAL);
$rs=$connect->query($sql);
$rs->setFetchMode(PDO::FETCH_BOTH);
$row=$rs->fetch();

if($row["CNT"] == 1){
	$sql2 = "SELECT * FROM train WHERE oCode='$oCode' and myid='$myid'";
	$connect->setAttribute(PDO::ATTR_CASE, PDO::CASE_NATURAL);
	$rs2=$connect->query($sql2);
	$rs2->setFetchMode(PDO::FETCH_BOTH);
	$row2=$rs2->fetch();
	
	echo $row2['myid'] . "<br>";
	echo $row2['dept'] . "<br>";
	echo $row2['arri'] . "<br>";
	echo $row2['way12'] . "<br>";
	echo $row2['mydate'] . "<br>";
	echo $row2['trainNo'] . "<br>";
	echo $row2['tNo'] . "<br>";
	echo "<a href='trainD.php?tid=" . $row2['tid'] . "'>刪除車票</a>";
}
else{
	echo '資料錯誤';
	header("refresh:1;url=trainQ.htm");
}
?>