<html>
	<head>
		<meta charset="utf-8">
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
		<title>出包網</title>
		<style>
			
			p{ font: 15pt 標楷體; }
			
			li{ 
				list-sytle:none;
				margin:10px 0px;
				font: 標楷體;
			}

			.focus{ color: #FF0000; }
			
			a {
				padding-top: 20px;
				color: #000000;
				text-decoration:none;
				font: 15pt 標楷體;
			}
			
			a:hover{ color: #F28500; }
			
		</style>
	</head>
	<body>
		<div style="padding:30px 15% 5px 15%; background-color:#00C0FF">
			<div class="row">
				<div class="col col-12 col-sm-12 col-md-9 col-lg-6 col-xl-3 text-center">
					<img src="img/Mlogo.jpg" class="img-fluid" style="max-width:100%; height:auto;">
				</div>
				<div class="col col-xs-3 col-sm-3 col-md-6 col-lg-2 col-xl-2 text-center">
					<a href="caseList.php">案件查詢</a>
				</div>
				<div class="col col-xs-2 col-sm-2 col-md-6 col-lg-1 col-xl-2 text-center">
					<a href="peopleList.php">人才查詢</a>
				</div>
				<div class="col col-xs-2 col-sm-2 col-md-6 col-lg-1 col-xl-2 text-center">
					<a href="">發案</a>
				</div>
				<div class="col col-xs-2 col-sm-2 col-md-6 col-lg-1 col-xl-2 text-center">
					<a href="personal.php">個人頁面</a>
				</div>
				<div class="col col-xs-3 col-sm-3 col-md-6 col-lg-1 col-xl-1 text-center">
					<?php
						if(!isset($_SESSION)){ session_start(); } //檢查SESSION是否啟動
						if(empty($_SESSION['position']))
							echo '<a href="Login.php">登入</a>';
						else
							echo '<a href="Logout.php">登出</a>';
					?>
				</div>
			</div>
		</div>
		<div style="padding:0px 15% 10px 15%">
			<div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
				<div class="carousel-indicators">
					<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
					<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
					<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
				</div>
				<div class="carousel-inner">
					<div class="carousel-item active">
						<img src="img/01.jpg" class="d-block w-100" alt="...">
					</div>
					<div class="carousel-item">
						<img src="img/02.jpg" class="d-block w-100" alt="...">
					</div>
					<div class="carousel-item">
						<img src="img/03.jpg" class="d-block w-100" alt="...">
					</div>
				</div>
				<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
					<span class="carousel-control-prev-icon" aria-hidden="true"></span>
					<span class="visually-hidden">Previous</span>
				</button>
				<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
					<span class="carousel-control-next-icon" aria-hidden="true"></span>
					<span class="visually-hidden">Next</span>
				</button>
			</div>
		</div>
		<div class="row" style="margin:0px 15%" id="case">
			<?php
				$arr=array("1" ,"2" ,"3" ,"4" ,"5" ,"6" ,"7" ,"8" ,"9" ,"10" ,"11" ,"12" ,"13" ,"14" ,"15" ,"16" ,"17" ,"18" ,"19" ,"20");
				foreach($arr as $i => $v){
					echo '<div style="padding:5px 0px">' . 
							'<div class="col col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">' . 
								'<ul>' . 
									'<li class="col-12 text-truncate"><h4>' . '接案者名字' . '</h4></li>' . 
									'<li class="col-12 text-truncate">' . 
										'<p> 經驗說明：' . 
											'介紹介紹介紹介紹介紹介紹介紹介紹介紹介紹介紹介紹介紹介紹介紹介紹介紹介紹介紹介紹介紹介紹介紹介紹介紹介紹介紹介紹介紹介紹介紹' . 
										'</p>' . 
									'</li>' . 
									'<li class="col-12 text-truncate clearfix">' . 
										'<a target="_blank" href="https://www.youtube.com">' . 
											'<button type="button" class="btn btn-danger float-end">查看個人頁面</button>' . 
										'</a>' . 
									'</li>' . 
								'</ul>' . 
							'</div>' . 
						'</div>';
				}
			?>
		</div>
		<div style="margin:0px 15%">
			<nav aria-label="Page navigation example">
				<ul class="pagination justify-content-end">
					<li class="page-item">
						<a class="page-link" href="#" aria-label="Previous">
							<span aria-hidden="true">&laquo;</span>
						</a>
					</li>
					<li class="page-item"><a class="page-link" href="#">1</a></li>
					<li class="page-item"><a class="page-link" href="#">2</a></li>
					<li class="page-item"><a class="page-link" href="#">3</a></li>
					<li class="page-item">
						<a class="page-link" href="#" aria-label="Next">
							<span aria-hidden="true">&raquo;</span>
						</a>
					</li>
				</ul>
			</nav>
		</div>
		<div class="text-center" style="margin-top:10px; padding:10px 0px; background-color:#00C0FF">
			<?php
				require_once("db/03_visitor_update.php");
			?>
		</div>
	</body>
</html>
