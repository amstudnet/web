<?php
session_start();
ini_set('display_errors','on');
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
include_once("../db/01_conn.php");

if(!empty($_POST['uid'])) $uid = $_POST['uid'];
if(!empty($_POST['password'])) $passwd = $_POST['password'];

$sql = "SELECT count(*) as CNT, role as R FROM member WHERE uid='$uid' and passwd='$passwd'";
$connect->setAttribute(PDO::ATTR_CASE, PDO::CASE_NATURAL);
$rs=$connect->query($sql);
$rs->setFetchMode(PDO::FETCH_BOTH);
$row=$rs->fetch();

if($row["CNT"] == 1){
	echo '帳密正確';
	$_SESSION['UID']=$uid;	
	if((!empty($_SESSION['check_word'])) && (!empty($_POST['checkword']))){  //判斷此兩個變數是否為空
		if($_SESSION['check_word'] != $_POST['checkword']){
			echo '驗證碼輸入錯誤';
			header("refresh:2;url=formLogin.htm");
		}
		else{
			$_SESSION['check_word'] = ''; //比對正確後，清空將check_word值
			if($row["R"] == 1){
				header("refresh:1;url=member_modify.php");
			}
			else if($row["R"] == 9){
				header("refresh:1;url=member_adm.php");
			}
		}
	}	
}
else{
	echo '帳密錯誤';
	header("refresh:1;url=formLogin.htm");
}
?>