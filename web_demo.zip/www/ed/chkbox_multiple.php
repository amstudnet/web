<script language="javascript">
function chkall(p){
	//var p = document.getElementsByName("sel[]");
	if(document.getElementById("e").checked){
		for(i=0; i<p.length; i++){
			p[i].checked = true;
		}
	}
	else{
		for(i=0; i<p.length; i++){
			p[i].checked = false;
		}
	}
}
</script>

<body>
	<form method="post" action="chkbox_multiple2.php" name="f2">
		<input type='checkbox' name='sAll' value='1' id="e" onclick="chkall(document.f2.sel)">全選/全不選<br>
		<?php
			$i = 1;
			while($i < 31){
				echo "<input type='checkbox' id='sel' name='sel[]' value='$i'>$i<br>";
				$i++;
			}
		?>
		<input type='submit' value="送出">
	</form>
</body>