<?php
	$sel2 = $_POST['sel'];
	/*
	for($i=0; $i<count($sel2); $i++){
		echo "sel2[$i]=$sel2[$i]<br>";
	}
	*/
	foreach($sel2 as $key => $value){
		echo "sel2[$key]=$value<br>";
	}
	echo "<a href='chkbox_multiple.php'>回上頁</a>";
?>