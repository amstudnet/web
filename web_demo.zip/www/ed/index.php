<html>
	<head>
		<meta charset="utf-8">
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
		<title>10911102陳建智</title>
		<style>
			.focus{
				color: #FF0000;
			}
			
			a {
				padding-left: 15px;
				color: #000000;
				text-decoration:none;
				font: 20pt 標楷體;
			}
			
			a:hover{
				color: #F28500;
			}
		</style>
	</head>
	<body>
		<div style="padding:20px 15%; background-color:#00C0FF">
			<img src="../img/Mlogo.jpg" style="padding-top:15px" style="float: left">
			<a href="https://enrl.nttu.edu.tw/" target="_blank">未來學生</a>
			<a class="focus" href="https://inc.nttu.edu.tw/" target="_blank">新生</a>
			<a href="https://www.nttu.edu.tw/p/426-1000-15.php?Lang=zh-tw" target="_blank">在校生</a>
			<a href="https://sec.nttu.edu.tw/p/404-1010-84364.php" target="_blank">校友</a>
			<a href="https://www.nttu.edu.tw/p/426-1000-16.php?Lang=zh-tw" target="_blank">教職員</a>
			<a class="focus" href="ftext.htm" target="_blank">表單</a>
			<a class="focus" href="chkbox_multiple.php" target="_blank">表單多選</a>
			<a class="focus" href="fex.htm" target="_blank">下拉</a>
			<a class="focus" href="10911102.php" target="_blank">日期作業</a>
			<a class="focus" href="formAll.htm" target="_blank">表單全部</a>
			<a href="formMember.htm" target="_blank">會員註冊</a>
			<a href="formLogin.htm" target="_blank">會員登入</a>
			<a href="trainF.htm" target="_blank">火車購票</a>
			<a href="trainQ.htm" target="_blank">火車訂票查詢</a>
			<br>
			<div style="text-align: center;">
			<?php
				require_once("../db/03_visitor_update.php");
			?>
			</div>
		</div>
		<div style="padding:0% 15%">
			<div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
				<div class="carousel-indicators">
					<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
					<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
					<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
				</div>
				<div class="carousel-inner">
					<div class="carousel-item active">
						<img src="../img/01.jpg" class="d-block w-100" alt="...">
					</div>
					<div class="carousel-item">
						<img src="../img/02.jpg" class="d-block w-100" alt="...">
					</div>
					<div class="carousel-item">
						<img src="../img/03.jpg" class="d-block w-100" alt="...">
					</div>
				</div>
				<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
					<span class="carousel-control-prev-icon" aria-hidden="true"></span>
					<span class="visually-hidden">Previous</span>
				</button>
				<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
					<span class="carousel-control-next-icon" aria-hidden="true"></span>
					<span class="visually-hidden">Next</span>
				</button>
			</div>
		</div>
		<video width="560" height="315" src="../video/countdown.mp4" controls loop autoplay></video>
		<iframe width="560" height="315" src="https://www.youtube.com/embed/AmXafXIczqg?si=NEwlabmBoEIbYo6Y" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
		<audio src="../audio/song.mp3" controls loop autoplay></audio>
		<div class="card" style="width: 18rem;">
			<img src="../img/01.jpg"></video>
			<div class="card-body">
				<p class="card-text">五個人坐著</p>
				<a href="https://www.nttu.edu.tw/" class="btn btn-primary">台東大學</a>
			</div>
		</div>
	</body>
</html>
