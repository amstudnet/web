<?php
	$ID = $_POST['id'];
	$PW = $_POST['pw'];
	$gender = ($_POST['gender'] == 0 ? '男' : '女');
	$sel = $_POST['sel'];
	$habbit = $_POST['habbit'];
	$city = t2city($_POST['city']);
	$date = $_POST['date'];
	$txt = $_POST['txt'];
	
	echo "帳號：$ID<br>\n密碼：$PW<br>\n性別：$gender<br>\n3選1：$sel<br>\n興趣：";
	foreach($habbit as $key => $value){
		echo t2habbit($value), " ";
	}
	echo "<br>\n居住地：$city<br>\n日期：$date<br>\n留言：$txt";
	
	
	function t2city($city){
		switch($city){
			case "1":
				return "台東";
			case "2":
				return "高雄";
			case "3":
				return "台南";
			case "4":
				return "屏東";
			default:
				return "未選擇";
		}
	}
	
	function t2habbit($tmp){
		switch($tmp){
			case "1":
				return "逛街";
			case "2":
				return "遛狗";
			case "3":
				return "運動";
			default:
				return "未選擇";
		}
	}
?>