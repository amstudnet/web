<html>
	<head>
		<meta charset="utf-8">
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
		<title>出包網</title>
		<style>
			a.focus {
				padding-top: 20px;
				color: #000000;
				text-decoration:none;
				font: 15pt 標楷體;
			}
			
			a.focus:hover{ color: #F28500; }
			
			#case > div > a:hover{ 
				color: #000000;
			}
		</style>
	</head>
	<body>
		<div style="padding:30px 15% 5px 15%; background-color:#00C0FF">
			<div class="row">
				<div class="col col-12 col-sm-12 col-md-9 col-lg-6 col-xl-3 text-center">
					<img src="img/Mlogo.jpg" class="img-fluid" style="max-width:100%; height:auto;">
				</div>
				<div class="col col-xs-3 col-sm-3 col-md-6 col-lg-2 col-xl-2 text-center">
					<a href="caseList.php" class="focus">案件查詢</a>
				</div>
				<div class="col col-xs-2 col-sm-2 col-md-6 col-lg-1 col-xl-2 text-center">
					<a href="peopleList.php" class="focus">人才查詢</a>
				</div>
				<div class="col col-xs-2 col-sm-2 col-md-6 col-lg-1 col-xl-2 text-center">
					<a href="" class="focus">發案</a>
				</div>
				<div class="col col-xs-2 col-sm-2 col-md-6 col-lg-1 col-xl-2 text-center">
					<a href="personal.php" class="focus">個人頁面</a>
				</div>
				<div class="col col-xs-3 col-sm-3 col-md-6 col-lg-1 col-xl-1 text-center">
					<?php
						if(!isset($_SESSION)){ session_start(); } //檢查SESSION是否啟動
						if(empty($_SESSION['position']))
							echo '<a href="Login.php" class="focus">登入</a>';
						else
							echo '<a href="Logout.php" class="focus">登出</a>';
					?>
				</div>
			</div>
		</div>
		<div style="padding:5% 15%">
			<?php
				session_start();
				if(empty($_SESSION['did'])) header("refresh:1;url=Login.php");
				
				ini_set('display_errors','on');
				error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
				include_once("./db/01_conn.php");
				
				$sql2="select * from peopleData where did='". $_SESSION['did'] . "'";
				
				$connect->setAttribute(PDO::ATTR_CASE, PDO::CASE_NATURAL);
				$rs2=$connect->query($sql2);
				$rs2->setFetchMode(PDO::FETCH_BOTH);
				$row2=$rs2->fetch();
			?>
			<form method="post" action="personal_modify2.php">
				<input type="hidden" name="did" value="<?php echo $row2["did"] ?>">
				<div class="mb-3">
					<label for="exampleInputEmail1" class="form-label">身分別：<?php session_start(); if($_SESSION['position']==1){echo '發案者';}else{echo '接案者';} ?></label><br>
				</div>
				<div class="mb-3">
					<label for="exampleInputEmail1" class="form-label">帳號</label>
					<input type="text" name="uid" class="form-control" value="<?php echo $row2['uid'] ?>">
				</div>
				<div class="mb-3">
					<label for="exampleInputPassword1" class="form-label">密碼</label>
					<input type="text" name="password" class="form-control" pattern="^(?=.*[a-zA-Z])(?=.*[0-9]).{6,}$" required="required" aria-describedby="passwordHelp" value="<?php echo $row2['passwd'] ?>"/>
				</div>
				<div class="mb-3">
					<label for="exampleInputEmail1" class="form-label">暱稱</label>
					<input type="text" name="name" class="form-control" value="<?php echo $row2['name'] ?>">
				</div>
				<div class="mb-3">
					<label for="exampleInputEmail1" class="form-label">身分證字號</label>
					<input type="text" name="ID" class="form-control" value="<?php echo $row2['ID'] ?>"/>
				</div>
				<div class="mb-3">
					<label for="exampleInputEmail1" class="form-label">電子信箱</label>
					<input type="email" name="email" class="form-control" required="required" pattern="[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$" value="<?php echo $row2['email'] ?>"/>
				</div>
				<div class="mb-3">
					<label for="exampleInputEmail1" class="form-label">電話</label>
					<input type="text" name="phone" class="form-control" required="required" maxlength="11" pattern="09\d{8}" value="<?php echo $row2['phone'] ?>"/>
				</div>
				<div class="mb-3">
					<label for="exampleInputEmail1" class="form-label">簡介</label><br>
					<textarea cols="30" rows="5" name="introdction"  value="<?php echo $row2['introdction'] ?>" aria-describedby="passwordHelp"></textarea>
					<div id="passwordHelp" class="form-text">限150字以內</div>
				</div>
				<button type="submit" class="btn btn-primary">儲存</button>
			</form>
		</div>
	</body>
</html>