<?php
	session_start();
	
	ini_set('display_errors','on');
	error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
	include_once("../db/01_conn.php");
	
	$mid = $_POST['mid']; $uid = $_POST['uid']; $passwd = $_POST['passwd'];
	$name = $_POST['name2']; $birthday = $_POST['birthday']; $mobile = $_POST['mobile'];

	try{
		$sql = "update member SET uid='$uid',passwd='$passwd',name='$name',birthday='$birthday',mobile='$mobile' 
				where mid='$mid'";
		//echo $sql."<br>\n";
		$msg='';

		$result =$connect->exec($sql);
		if($result === false){
			$msg="fail update. <br>\n";
		} 
		if($msg != '') echo $msg;
		else{
			echo "修改成功";
			header("refresh:1;url=index.php");
		}
	}catch(PDOException $e){
		echo $e->getMessage() . "<br>\n";
	}
?>