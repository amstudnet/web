<?php
	echo '<select>';
	$days = 28;
	echo '<option selected>選擇日期</option>';
	for($i=0; $i<=$days; $i++){
		echo '<option value="1">', date('Y-m-d', strtotime(sprintf("+%d day",$i))), ' [', num2ch(date('N', strtotime(sprintf("+%d day",$i)))), ']', '</option>';
	}
	echo '</select>';
	
	function num2ch($num){
		switch($num){
			case '1':
				return "一";
			case '2':
				return "二";
			case '3':
				return "三";
			case '4':
				return "四";
			case '5':
				return "五";
			case '6':
				return "六";
			case '7':
				return "日";
		}
	}
?>